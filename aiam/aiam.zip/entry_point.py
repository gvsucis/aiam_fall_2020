# !/usr/bin/env python
import scrapy
from scrapy.cmdline import execute

execute(['scrapy', 'crawl', 'general'])