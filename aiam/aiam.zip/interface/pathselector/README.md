﻿# Using PathSelector Extension

Hi! I'm your first Markdown file in **StackEdit**. If you want to learn about StackEdit, you can read me. If you want to play with Markdown, you can edit me. Once you have finished with me, you can create new files by opening the **file explorer** on the left corner of the navigation bar.


# Set Up

Open Firefox and in the address bar enter:  **about:debugging**
This will open up a new page. On the left side click **This Firefox**
Another new page will open and you should see bold text that says "Temporary Extensions". Now click the button **Loaded Temporary Add-On...**
This will open up a file explorer. Navigate to where the github repo is installed. Then go into the interfaces folder and then to the PathSelector folder. Once inside choosing any of the files contained in PathSelector will successfully load the extension.

# Usage
Navigate to your target website. Once on the desired website click the extension icon that should be seen in the top right of the browser's toolbar. Press the + button to run the extension on the page. After pressing the button, clicking on any text within the website will copy that text's xpath to your clipboard!
